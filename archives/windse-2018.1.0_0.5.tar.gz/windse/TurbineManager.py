class GenericTurbine(object):
    def __init__(self, loc, RD, W):
        self.loc = loc # Location in Space
        self.RD  = RD  # Rotor Diameter
        self.W   = W   # Width of influence